create table agendamento(
	horadata TIMESTAMP not null,
	profissional varchar(100) not null,
	cliente varchar(100) not null,
	procedimento varchar(100) not null
);

create table tabela(
	horadata TIMESTAMP not null,
	profissional varchar(100) not null,
	clienteProcedimento varchar(100) not null
);
