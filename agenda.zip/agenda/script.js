function salvarAgendamento(){
  document.getElementById('formAgendamento').submit();
}

function excluirAgendamento(){

}

function editarAgendamento(){

}