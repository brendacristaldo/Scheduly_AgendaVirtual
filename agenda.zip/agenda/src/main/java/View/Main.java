/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

import Model.Estabelecimento;
import Model.Agenda;

/**
 *
 * @author Brenda Cristaldo
 */
public class Main {
    public static void main(String[] args){
        String nome = "brenda";
            System.out.println(nome);
            
        Estabelecimento veiga = new Estabelecimento ("Clinica Veiga", "12991008531", "rua 1 numero 36", "veiga@gmail.com", "veiga123");
        Agenda a = new Agenda("brenda", "profissional 1", "manicure", "26/06/2024 09:00");
        System.out.println(a.getNome());
        System.out.println(a.getData());
        System.out.println(a.getProcedimento());
    }
}
