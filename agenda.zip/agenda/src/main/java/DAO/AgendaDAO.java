/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Model.Agenda;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AgendaDAO {
    private final Connection connection;

    public AgendaDAO(Connection connection) {
        this.connection = connection;
    }
    
    public void inserir(Agenda agenda) throws SQLException {
        String sql = "INSERT INTO agenda (nome_cliente, nome_profissional, procedimento, dia_hora, estabelecimento_email) VALUES(?,?,?,?,?)";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, agenda.getNome());
        ps.setString(2, agenda.getProfissional());
        ps.setString(3, agenda.getProcedimento());
        ps.setString(4, agenda.getData());
        ps.setString(5, agenda.getEmail());
        ps.execute();
    }
    
    public boolean existeEmail(Agenda aAutenticacao) throws SQLException {
        String sql = "SELECT * FROM estabelecimento WHERE email = ?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, aAutenticacao.getEmail());
        ResultSet resultSet = ps.executeQuery();
        return resultSet.next();
    }

    public List<Agenda> getByEmail(String email) throws SQLException {
        String sql = "SELECT * FROM agenda WHERE estabelecimento_email = ?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, email);
        ResultSet resultSet = ps.executeQuery();

        List<Agenda> agendas = new ArrayList<>();
        while (resultSet.next()) {
            Agenda agenda = new Agenda(
                resultSet.getString("nome_cliente"),
                resultSet.getString("nome_profissional"),
                resultSet.getString("procedimento"),
                resultSet.getString("dia_hora"),
                resultSet.getString("estabelecimento_email")
            );
            agendas.add(agenda);
        }
        return agendas;
    }

    public void excluir(Agenda agenda) throws SQLException {
        String sql = "DELETE FROM agenda WHERE nome_cliente = ? AND nome_profissional = ? AND procedimento = ? AND dia_hora = ? AND estabelecimento_email = ?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, agenda.getNome());
        ps.setString(2, agenda.getProfissional());
        ps.setString(3, agenda.getProcedimento());
        ps.setString(4, agenda.getData());
        ps.setString(5, agenda.getEmail());
        ps.executeUpdate();
    }
    
    public void deleteByNomeCliente(String nomeCliente) throws SQLException {
        String sql = "DELETE FROM agenda WHERE nome_cliente = ?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, nomeCliente);
        ps.executeUpdate();
    }
    
    public void deleteByEstabelecimentoEmail(String email) throws SQLException {
        String sql = "DELETE FROM agenda WHERE estabelecimento_email = ?";
        PreparedStatement ps = connection.prepareStatement(sql);
        ps.setString(1, email);
        ps.execute();
    }

}
