/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Controller.helper.AgendaHelper;
import DAO.AgendaDAO;
import DAO.Conexao;
import Model.Agenda;
import View.AgendaGUI;
import View.Editar;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;

public class AgendaController {
    private final AgendaGUI view;
    private final AgendaHelper helper;

    public AgendaController(AgendaGUI view) {
        this.view = view;
        this.helper = new AgendaHelper(view);
    }
       
    public void autenticar() throws SQLException {
        String email = view.getEmailField().getText();
        
        Agenda aAutenticacao = new Agenda(email);
        
        Connection conexao = new Conexao().getConnection();
        AgendaDAO adao = new AgendaDAO(conexao);
        
        boolean existe = adao.existeEmail(aAutenticacao);
        
        if (existe) {
            String nome = view.getNomeField().getText();
            String prof = view.getProfField().getText();
            String proc = view.getProcField().getText();
            String data = view.getDataField().getText();
        
            Agenda agenda = new Agenda(nome, prof, proc, data, email);
            adao.inserir(agenda);
        } else {
            JOptionPane.showMessageDialog(null, "Esse e-mail não existe!");
        }
    }

    public void atualizarTabela(String email) throws SQLException {
        Connection conexao = new Conexao().getConnection();
        AgendaDAO adao = new AgendaDAO(conexao);
        List<Agenda> agendas = adao.getByEmail(email);
        helper.preencherTabela(agendas);
    }

    public void excluirAgendamento() throws SQLException {
        String nome = view.getNomeField().getText();
        String prof = view.getProfField().getText();
        String proc = view.getProcField().getText();
        String data = view.getDataField().getText();
        String email = view.getEmailField().getText();
        
        Connection conexao = new Conexao().getConnection();
        AgendaDAO adao = new AgendaDAO(conexao);
        
        Agenda agenda = new Agenda(nome, prof, proc, data, email);
        adao.excluir(agenda);
        
        atualizarTabela(email); // Atualiza a tabela após a exclusão
    }
}
