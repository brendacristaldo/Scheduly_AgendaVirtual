/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Controller.helper.AgendaHelper;
import DAO.AgendaDAO;
import DAO.Conexao;
import Model.Agenda;
import View.AgendaGUI;
import View.Editar;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Brenda Cristaldo
 */
public class AgendaController {
    private final AgendaGUI view;
    private final AgendaHelper helper;

    public AgendaController(AgendaGUI view) {
        this.view = view;
        this.helper = new AgendaHelper(view);
    }
    
    public void navegarParaEditar(){
        Editar editar = new Editar();
        editar.setVisible(true);
    }
    
    /*public void atualizaTabela(){
        AgendaDAO adao = new AgendaDAO();
        
        //buscar lista com agendamentos no banco de dados
        adao.selecionarAgenda();
        
        //exibir lista na view
        helper.preencherTabela();
    }
    
    public void agendar(){
        Agenda agenda = helper.obterModelo();
        new AgendaDAO.inserir(agenda);
        atualizaTabela();
    }*/
    
    public void autenticar() throws SQLException {
        
        String email = view.getEmailField().getText();
        
        Agenda aAutenticacao = new Agenda(email);
        
        Connection conexao = new Conexao().getConnection();
        AgendaDAO adao = new AgendaDAO(conexao);
        
        boolean existe = adao.existeEmail(aAutenticacao);
        
        if(existe){
            String nome = view.getNomeField().getText();
        String prof = view.getProfField().getText();
        String proc = view.getProcField().getText();
        String data = view.getDataField().getText();
        
        Agenda agenda = new Agenda(nome, prof, proc, data, email);
            adao.inserir(agenda);
        }else{
            JOptionPane.showMessageDialog(null, "Esse estabelecimento nao existe!");
        }
        
    }
}
