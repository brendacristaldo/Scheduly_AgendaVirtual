/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import DAO.Conexao;
import DAO.EstabelecimentoDAO;
import Model.Estabelecimento;
import View.AgendaGUI;
import View.Login;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class LoginController {

    private final Login view;
    public static String emailLogado;

    public LoginController(Login view) {
        this.view = view;
    }
    
    public void autenticar() throws SQLException {
        
        String email = view.getEmailField().getText();
        String senha = new String(view.getSenhaField().getPassword());
        
        Estabelecimento eAutenticacao = new Estabelecimento(email,senha);
        
        Connection conexao = new Conexao().getConnection();
        EstabelecimentoDAO estdao = new EstabelecimentoDAO(conexao);
        
        boolean existe = estdao.existeEmailSenha(eAutenticacao);
        
        if(existe){
            emailLogado = email;
            AgendaGUI agenda = new AgendaGUI();
        agenda.setVisible(true);
        view.dispose();
        }else{
            JOptionPane.showMessageDialog(null, "Email ou senha invalidos!");
        }
        
    }
    
}
