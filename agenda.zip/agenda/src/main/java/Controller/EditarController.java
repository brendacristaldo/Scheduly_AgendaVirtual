/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import DAO.AgendaDAO;
import DAO.Conexao;
import DAO.EstabelecimentoDAO;
import Model.Estabelecimento;
import View.Cadastro;
import View.Editar;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class EditarController {
    
    private Editar view;
    public static String emailLogado;

    public EditarController(Editar view) {
        this.view = view;
    }
        
    public void editarEstabelecimento() throws SQLException{
        
            String nome = view.getNomeField().getText();
            String tel = view.getTelField().getText();
            String end = view.getEndField().getText();
            String email = view.getEmailField().getText();
            String senha = view.getSenhaField().getText();
            
        Estabelecimento eEmail = new Estabelecimento(email);
        
        Estabelecimento est = new Estabelecimento(nome, tel, end, email, senha);
        Connection conexao = new Conexao().getConnection();
        
        EstabelecimentoDAO estdao = new EstabelecimentoDAO(conexao);
        boolean existe = estdao.existeEmail(eEmail);
        
        if(existe){
            try {
                estdao.editar(est);
                JOptionPane.showMessageDialog(null, "Alteração realizada com sucesso!");
            } catch (SQLException ex) {
                Logger.getLogger(Cadastro.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else{
              JOptionPane.showMessageDialog(null, "Email inválido!");
          }
    }
    
    public void excluirEstabelecimento(String email) throws SQLException {
        
        //String email = view.getEmailField().getText();
        Connection conexao = new Conexao().getConnection();
        Estabelecimento eEmail = new Estabelecimento(email);
        
        EstabelecimentoDAO estabelecimentoDAO = new EstabelecimentoDAO(conexao);
        AgendaDAO agendaDAO = new AgendaDAO(conexao);
        
        boolean existe = estabelecimentoDAO.existeEmail(eEmail);
         if(existe){
             // Excluir agendamentos do estabelecimento
                agendaDAO.deleteByEstabelecimentoEmail(email);
                // Excluir estabelecimento
                estabelecimentoDAO.deletarByEmail(email);
                JOptionPane.showMessageDialog(null, "Estabelecimento e seus agendamentos foram excluídos com sucesso.");
                view.dispose();
        }else{
              JOptionPane.showMessageDialog(null, "Esse e-mail não esta cadastrado!");
          }   
    }
}
