/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller.helper;

import View.AgendaGUI;
import Model.Agenda;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class AgendaHelper {

    private final AgendaGUI view;

    public AgendaHelper(AgendaGUI view) {
        this.view = view;
    }

    public void preencherTabela(List<Agenda> agendas) {
        DefaultTableModel tableModel = (DefaultTableModel) view.getjTableAgenda().getModel();
        tableModel.setRowCount(0); // Limpa a tabela

        for (Agenda agenda : agendas) {
            tableModel.addRow(new Object[]{
                agenda.getNome(),
                agenda.getProfissional(),
                agenda.getProcedimento(),
                agenda.getData(),
                agenda.getEmail()
            });
        }
    }
}
