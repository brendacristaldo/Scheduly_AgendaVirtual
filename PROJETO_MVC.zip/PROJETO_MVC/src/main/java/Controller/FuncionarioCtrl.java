/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import Model.Agendamento;
import Model.Cliente;
import Model.Funcionario;
import Model.Procedimento;
import java.util.List;
import java.util.ArrayList;

public class FuncionarioCtrl {
    List<Agendamento> listAgendamento = new ArrayList<>();
    private Cliente cliente;

    public FuncionarioCtrl() {
        this.listAgendamento = new ArrayList<>();
    }

    public void agendar(Cliente clienteNome, Funcionario funcionario, Procedimento procedimento, String data, String horario){
        Agendamento novoAgendamento = new Agendamento(cliente, funcionario, procedimento, data, horario);
        listAgendamento.add(novoAgendamento);
        System.out.println("Agendamento criado com sucesso.");
    }

    public void editarAgendamento(Agendamento agendamento, Procedimento novoProcedimento, String novaData, String novoHorario) {
        agendamento.setProcedimento(novoProcedimento);
        agendamento.setData(novaData);
        agendamento.setHorario(novoHorario);
        System.out.println("Agendamento editado com sucesso.");
    }

    public void cancelarAgendamento(Agendamento agendamento) {
        listAgendamento.remove(agendamento);
        System.out.println("Agendamento cancelado com sucesso.");
    }

}
