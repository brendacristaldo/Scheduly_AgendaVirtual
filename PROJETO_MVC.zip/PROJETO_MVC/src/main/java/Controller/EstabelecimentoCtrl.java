/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Estabelecimento;
import View.Estabelecimento_CadastroGUI;


public class EstabelecimentoCtrl {

    //private Estabelecimento e;
    private Estabelecimento_CadastroGUI tc;
    //private DAO daoe;
    //private Estabelecimento_CadastroGUI tc;
    
    // caso os dados cadastrados tenham sido recebidos adequadamente ele vai responder verdade um verdadeiro
    //e caso tenha algum dado que não tenha sido preenchido corretamente ele vai responder falso
    public boolean EstabelecimentoCtrl(String nome, int telefone, String endereco, String email, String senha){
        if (nome != null && nome.length() > 0 && telefone != null && telefone.length()>0 && endereco != null 
                && endereco.length()>0 && email != null && email.length()>0 && senha != null && senha.length()>0){
            Estabelecimento estabelecimento = new Estabelecimento(nome,telefone, endereco, email,senha);
            
            estabelecimento.cadastrar(estabelecimento);
            return true;            
        }
        return false;
    }
    
    public void cadastrar(){
        
    }
    
    /*public void actionPerformed(ActionEvent es) {
        JButton botaoapertado = (JButton)es.getSource();
        String email = botaoapertado.getName();
        switch(email){
            case "entrar":
                //Buscar da tela o código do cliente
                //tl.getEstabelecimento(e);
                //Executar o método buscar do BDCliente
                //daoe.logar(e);break;
            case "cadastrar":
                //Buscar da tela o código do cliente
                tc.getCadastro(e);
                //Executar o método buscar do BDCliente
                daoe.cadastrar(e);break;
            case "editar":
                //Pegar os dados digitados na janela
                //E colocá-los no objeto cliente
                //tc.getCadastro(e);
                //daoe.buscar(e);
                //tc.apresentar(e);break;
               
        }
    }*/
}





