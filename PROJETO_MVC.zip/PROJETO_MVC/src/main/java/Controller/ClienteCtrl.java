/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Cliente;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Brenda Cristaldo
 */
public class ClienteCtrl {
    List<Cliente> listCliente = new ArrayList<>();
    
    public void inserirCliente(Cliente cliente){
        listCliente.add(cliente);
    }
    
    public void inserirCliente(Integer telefone, String nome, String email){
        Cliente cliente = new Cliente(telefone, nome, email);
        listCliente.add(cliente);
    }
    
    public void deletarCliente(Integer telefone) {
        Cliente clienteAuxiliar = null;
        for (Cliente cliente : listCliente) {
            if (Integer.valueOf(cliente.getTelefone()).equals(telefone)) {
                clienteAuxiliar = cliente;
                break;
            }
        }

        if (clienteAuxiliar != null) {
            listCliente.remove(clienteAuxiliar);
            System.out.println("Cliente com o telefone " + telefone + " deletado com sucesso.");
        } else {
            System.out.println("Não foi encontrado nenhum cliente com o telefone " + telefone + ".");
        }
    }
    
    public void atualizarCliente(Cliente clienteAtualizado) {
        boolean atualizado = false;
        for (Cliente cliente : listCliente) {
            if (cliente.getTelefone() == clienteAtualizado.getTelefone()) {

                cliente.setTelefone(clienteAtualizado.getTelefone());
                cliente.setNome(clienteAtualizado.getNome());
                cliente.setEmail(clienteAtualizado.getEmail());

                atualizado = true;

                System.out.println("Informações do cliente com telefone " + clienteAtualizado.getTelefone() + " atualizadas com sucesso.");
                break;
            }
        }

        if (!atualizado) {
            System.out.println("Não foi encontrado nenhum cliente com o telefone " + clienteAtualizado.getTelefone() + ".");
        }
    }
    
    public void imprimirLista() {
        if (listCliente.isEmpty()) {
            System.out.println("A lista de clientes está vazia.");
        } 
        
        else {
            System.out.println("Lista de clientes:");
            
            for (Cliente cliente : listCliente) {
                System.out.println("Nome: " + cliente.getNome());
                System.out.println("Telefone: " + cliente.getTelefone());
                System.out.println("E-mail: " + cliente.getEmail());
                System.out.println("------------------------");
            }
        }
    }
}
