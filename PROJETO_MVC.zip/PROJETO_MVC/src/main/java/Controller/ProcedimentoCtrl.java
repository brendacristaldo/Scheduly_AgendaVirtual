/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;


import Model.Procedimento;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Brenda Cristaldo
 */
public class ProcedimentoCtrl {
    List<Procedimento> listProcedimento = new ArrayList<>();
    
    public void inserirProcedimento(Procedimento procedimento){
        listProcedimento.add(procedimento);
    }
    
    public void inserirProcedimento(Integer telefone, String nome, String email){
        Procedimento procedimento = new Procedimento(nome);
        listProcedimento.add(procedimento);
    }
    
    public void deletarProcedimento(String nome) {
        Procedimento procedimentoAuxiliar = null;
        for (Procedimento procedimento : listProcedimento) {
            if (procedimento.getNome().equals(nome)) {
                procedimentoAuxiliar = procedimento;
                break;
            }
        }

        if (procedimentoAuxiliar != null) {
            listProcedimento.remove(procedimentoAuxiliar);
            System.out.println("Funcionario com o nome " + nome + " deletado com sucesso.");
        } else {
            System.out.println("Não foi encontrado nenhum funcionario com o nome " + nome + ".");
        }
    }
    
    public void atualizarProcedimento(Procedimento procedimentoAtualizado) {
        boolean atualizado = false;
        for (Procedimento procedimento : listProcedimento) {
            if (procedimento.getNome() == procedimentoAtualizado.getNome()) {

                procedimento.setNome(procedimentoAtualizado.getNome());

                atualizado = true;

                System.out.println("Informações do procedimento com o nome " + procedimentoAtualizado.getNome() + " atualizadas com sucesso.");
                break;
            }
        }

        if (!atualizado) {
            System.out.println("Não foi encontrado nenhum procedimento com o nome " + procedimentoAtualizado.getNome() + ".");
        }
    }
    
    public void imprimirLista() {
        if (listProcedimento.isEmpty()) {
            System.out.println("A lista de procedimentos está vazia.");
        } 
        
        else {
            System.out.println("Lista de procedimentos:");
            
            for (Procedimento procedimento : listProcedimento) {
                System.out.println("Nome: " + procedimento.getNome());
                System.out.println("------------------------");
            }
        }
    }
}
