/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Estabelecimento;
import java.sql.*;
import javax.swing.JOptionPane;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.DriverManager;


/**
 *
 * @author Brenda Cristaldo
 */
public class DAO {
       static final String driver = "com.mysql.cj.jdbc.Driver"; 
       static final String url = "jdbc:mysql://localhost:3306/banco"; 
       static final String user = "root"; 
       static final String senha = "root";
    private String SQL;
       
       public void cadastrar(Estabelecimento estabelecimento) {
           Connection conn = null;
           PreparedStatement ps = null;
           try{
            //Class.forName(driver);
            conn = DriverManager.getConnection(url,user,senha);
            String sql1 = "INSERT INTO estabelecimento(nome, telefone, email, endereco, senha) VALUES(?,?,?,?,?)";
            ps = conn.prepareStatement(sql1);
            ps.setString(1, estabelecimento.getNome());
            ps.setInt(2, estabelecimento.getTelefone());
            ps.setString(3, estabelecimento.getEmail());
            ps.setString(4, estabelecimento.getEndereco());
            ps.setString(5, estabelecimento.getSenha());
            System.out.println("Criando a tabela...");
            
            ps.executeUpdate(sql1); 
            System.out.println("Dados inseridos com sucesso!"); 
            ps.close(); 
            conn.close(); 
           }catch(Exception ex){ 
                System.out.println(ex);
           } 
       }
       
       public void logar (Estabelecimento e){
       Connection conn = null;
       PreparedStatement ps = null;
       Statement st = null; 
       ResultSet rs = null;
       
        try{
  
            ps.executeQuery(SQL);

            rs.next();

            if(e.getEmail().equals(rs.getString("email")) 
                    && e.getSenha().equals(rs.getString("senha"))){
                JOptionPane.showMessageDialog(null, "Usuário Correto");
            }else{
                JOptionPane.showMessageDialog(null, "Usuário Inválido");
            }
           rs.close(); 
           st.close(); 
           conn.close(); 
        }catch(SQLException ex){
            System.out.println("ex");
        }
        
       }
       
       public void editar(Estabelecimento e){
           
           Connection conn = null;
            PreparedStatement ps = null;
            Statement st = null; 
          
           ResultSet rs = null; 
           String sql4 = "update estabelecimento set idade = 30";
            
           try{ 
           Class.forName(driver); 
           conn = DriverManager.getConnection(url,user,senha); 
           st = conn.createStatement(); 
           st.executeUpdate(sql4); 
           rs.close(); 
           conn.close(); 
            }catch(Exception ex){
                System.out.println("nao foi possivel editar os campos, por vaor tente novamente!");
            }
       }
       
}
