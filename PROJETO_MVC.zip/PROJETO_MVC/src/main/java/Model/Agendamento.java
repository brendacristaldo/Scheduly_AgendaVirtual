/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.sql.Time;
import java.util.ArrayList;
import java.util.Date;


/**
 *
 * @author Brenda Cristaldo
 */
public class Agendamento{
    /*public Agenda(String clienteNome, String profissional, String procedimento, Date data, Time horario) {
        this.clienteNome = clienteNome;
        this.profissional = profissional;
        this.procedimento = procedimento;
        this.data = data;
        this.horario = horario;
    }*/
    private String nome;
    private String profissional;
    private String procedimento;
    private Date data;
    private Time horario;
    private ArrayList<Agendamento> agenda = new ArrayList<Agendamento>();

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getProfissional() {
        return profissional;
    }

    public void setProfissional(String profissional) {
        this.profissional = profissional;
    }

    public String getProcedimento() {
        return procedimento;
    }

    public void setProcedimento(String procedimento) {
        this.procedimento = procedimento;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public Time getHorario() {
        return horario;
    }

    public void setHorario(Time horario) {
        this.horario = horario;
    }
    
}