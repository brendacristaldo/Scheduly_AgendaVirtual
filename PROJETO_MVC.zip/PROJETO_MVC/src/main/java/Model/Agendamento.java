/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;


/**
 *
 * @author Brenda Cristaldo
 */
public class Agendamento{
    private Cliente clienteNome;
    private Funcionario funcionario;
    private Procedimento procedimento;
    private String data;
    private String horario;

    public Agendamento(Cliente clienteNome, Funcionario funcionario, Procedimento procedimento, String data, String horario) {
        this.clienteNome = clienteNome;
        this.funcionario = funcionario;
        this.procedimento = procedimento;
        this.data = data;
        this.horario = horario;
    }

    public Cliente getClienteNome() {
        return clienteNome;
    }

    public void setClienteNome(Cliente clienteNome) {
        this.clienteNome = clienteNome;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    public Procedimento getProcedimento() {
        return procedimento;
    }

    public void setProcedimento(Procedimento procedimento) {
        this.procedimento = procedimento;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    
}