/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_mvc;

/**
 *
 * @author Brenda Cristaldo
 */
public class PROJETO_MVC {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
