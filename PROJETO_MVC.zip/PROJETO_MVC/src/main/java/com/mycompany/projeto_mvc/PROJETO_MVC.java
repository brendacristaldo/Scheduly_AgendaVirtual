/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_mvc;

import View.Estabelecimento_CadastroGUI;
import java.sql.Connection;  
import java.sql.DriverManager; 

public class PROJETO_MVC {

    static Connection conn = null;
       public static String driver = "com.mysql.cj.jdbc.Driver"; 
       public static String url = "jdbc:mysql://localhost:3306/banco"; 
       public static String user = "root"; 
       public static String senha = "root";
    
    public static void main(String[] args) {
        
         try{
            System.out.println("Carregando o driver..."); 
            Class.forName(driver); 
            System.out.println("Driver carregado com sucesso"); 
         }catch(Exception e){ 
            System.out.println("Falha no carregamento"); 
         }
          try{ 
            System.out.println("Conectando o BD...");
            conn = DriverManager.getConnection(url,user,senha);
            System.out.println("Conexao realizada com sucesso");
          }catch(Exception e){ 
            System.out.println("Falha na conexao com o BD"); 
         }
          
          Estabelecimento_CadastroGUI ec = new Estabelecimento_CadastroGUI(); 
    }
}
