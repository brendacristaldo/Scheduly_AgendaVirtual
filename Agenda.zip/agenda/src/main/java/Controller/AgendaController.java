/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Controller.helper.AgendaHelper;
import DAO.AgendaDAO;
import View.Agenda;
import View.Editar;

/**
 *
 * @author Brenda Cristaldo
 */
public class AgendaController {
    private final Agenda view;
    private final AgendaHelper helper;

    public AgendaController(Agenda view) {
        this.view = view;
        this.helper = new AgendaHelper(view);
    }
    
    public void navegarParaEditar(){
        Editar editar = new Editar();
        editar.setVisible(true);
    }
    
    /*public void atualizaTabela(){
        AgendaDAO adao = new AgendaDAO();
        
        //buscar lista com agendamentos no banco de dados
        adao.selecionarAgenda();
        
        //exibir lista na view
        helper.preencherTabela();
    }
    
    public void agendar(){
        Agenda agenda = helper.obterModelo();
        new AgendaDAO.inserir(agenda);
        atualizaTabela();
    }*/
}
